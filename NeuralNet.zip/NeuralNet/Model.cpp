#define HAVE_STRUCT_TIMESPEC
#include <pthread.h>
#include "pch.h"
#include <fstream>
#include <iostream>
#include "Model.h"
#include <string>	
#include <cstring>	
#include <iomanip>  
#include <ctime>
#include <math.h>
#define BIAS 1 // Yanl�l�k De�eri
#define InputSize 784 //28*28 Image Pixel De�erleri
#define TrainCount 400 // Sisteme ��retilecek De�er Say�s�
//#define TestCount 1000 // Sistemde Test Edilecek De�er Say�s�
#define LAMDA1 0.000001
#define LAMDA2 0.9 //0.5

pthread_t thread1, thread2;

// Train Dosyas�ndaki Her Sat�r Boyutunu ��ren
	void Model::LearnRowSize(std::string img_file_path, std::string TrainOrTest, int DataCount) {
		std::ifstream infile;
		infile.open(img_file_path);
		if (infile.is_open()) {
			int i = 1, ToT = 0;
			std::string allRow;
			RED;
			if (TrainOrTest == "Train") ToT = TrainCount;
			else if (TrainOrTest == "Test") ToT = TestCount;
			else ToT = DataCount;
			WHITE;
			subRowSize = new int[ToT];
			subRowSize[0] = 0;
			while (getline(infile, allRow)) {  //Satir Satir Okunuyor.
				if (i < ToT) {
					subRowSize[i] = allRow.length();
					subRowSize[i] += subRowSize[i - 1];
					//std::cout << "subRowSize" << subRowSize[i] << " ";
					i++;
				}
				else 
					break;
			}
		}
		else {
			RED;
			std::cout << "LearnRowSize Function don't Open File!\n";
			WHITE;
		}			
		infile.close();
	}
// Train Dosyas�n� Oku
	void Model::ReadTrainDatas(std::string img_file_path, int row) { //For one row
		std::ifstream infile;
		infile.open(img_file_path);
		if (infile.is_open()) {
			std::string allRow;
			std::string delimiter = ",";
			trainInput = new double[InputSize + 2];
			for (int i = 0; i < InputSize + 2; i++) {
				trainInput[i] = 0;
			}

			infile.seekg(subRowSize[row] + 2 * row, std::ios::beg);
			while (getline(infile, allRow)) {
				size_t pos = 0;
				std::string token;
				int num = 0;
				while ((pos = allRow.find(delimiter)) != std::string::npos) {
					token = allRow.substr(0, pos);
					trainInput[num] = std::stoi(token);
					allRow.erase(0, pos + delimiter.length());
					num++;
				}
				trainInput[num] = std::stoi(allRow);
				num++;
				trainInput[num] = BIAS;
				break;
			}
		}
		else {
			std::cout << "Train Dosyasi Okuma Hatasi! \n";
		}

		infile.close();
	}
// Train Matrisini Olu�tur
	void Model::CreatTrainMtrx(std::string img_file_path) {
		input_G = new double*[TrainCount];
		for (int i = 0; i < TrainCount; i++) {
			input_G[i] = new double[InputSize + 1];//1 azalt�ld�
		}
		LearnRowSize(img_file_path, "Train", 0);
		for (int i = 0; i < TrainCount; i++) {
			ReadTrainDatas(img_file_path, i);
			for (int j = 0; j < InputSize+1; j++) {
				if (j == 0) {
					input_G[i][j] = trainInput[j]; //��retilecek De�er
				}
				else {
					input_G[i][j] = trainInput[j] / 255; // Pixel de�erleri reel yap�ld�.
				}
			}
		}
		delete[] trainInput;
		delete[] subRowSize;
	}
// Test Matrisini Olu�tur
	void Model::CreatTestMtrx(std::string img_file_path) {
		test_G = new double*[TestCount];
		for (int i = 0; i < TestCount; i++) {
			test_G[i] = new double[InputSize + 1];//
		}
		LearnRowSize(img_file_path, "Test", 0);
		for (int i = 0; i < TestCount; i++) {
			ReadTrainDatas(img_file_path, i);
			for (int j = 0; j < InputSize + 1; j++) {
				if (j == 0) {
					test_G[i][j] = trainInput[j]; //��retilecek De�er
				}
				else {
					test_G[i][j] = trainInput[j] / 255; // Pixel de�erleri reel yap�ld�.
				}
			}
		}
		delete[] trainInput;
		delete[] subRowSize;
	}
// A��rl�k Matrislerini Olu�tur
	void Model::CreateWeightMtrx(std::string img_file_path, std::string name) {
		int i=0, j=0;
		std::ifstream infile;
		infile.open(img_file_path);
		if (infile.is_open()) {
			if (name == "W") {
				width = InputSize;
				infile >> height;
				weight_W = new double*[height];
				for (i = 0; i < height; i++) {
					weight_W[i] = new double[width + 1];
					for (j = 0; j < width + 1; j++) {
						weight_W[i][j] = 0.0;
						infile >> weight_W[i][j];
					}
				}
				GREEN; std::cout << "*** 1. Weight Matrix is Created :) ***\n"; WHITE;
				BLUE;  std::cout << "+++ 1. Agirlik Matrisi W[" << height << "][" << width << "] +++\n\n"; WHITE;
			}
			else if (name == "Y") {
				if (height == 0) {
					RED;  std::cout << "*** First It Must Created 1.Weight Matrix! :( ***\n"; WHITE;
				}
				else {
					width = height;
					infile >> height;
					weight_Y = new double*[height];
					for (i = 0; i < height; i++) {
						weight_Y[i] = new double[width + 1];
						for (j = 0; j < width + 1; j++) {
							weight_Y[i][j] = 0.0;
							infile >> weight_Y[i][j];
						}
					}
					GREEN;  std::cout << "*** 2. Weight Matrix is Created :) *** \n"; WHITE;
					BLUE;  std::cout << "+++ 2. Agirlik Matrisi W[" << height << "][" << width << "] +++\n\n"; WHITE;
				}
			}
			else {
				RED;  std::cout << "*** Weight Matrix Not Recognized! *** \n"; WHITE;
			}
		}
		else {
			RED;  std::cout << "*** Weight Matrix File Not Opened! *** \n"; WHITE;
		}
		infile.close();
	}
// Yeni Test Dosyas� Olu�tur
	void Model::CreateTestFile(std::string img_file_read, std::string img_file_write, int DataCount) {
		int max = DataCount * 10, min = 0, row = 1;
		std::ofstream outfile;
		outfile.open(img_file_write, std::ios::out);
		srand(time(NULL));
		LearnRowSize(img_file_read, "TestFile", max);
		for (int i = 0; i < DataCount; i++) {
			row = rand() % (max - min + 1) + min;
			ReadTrainDatas(img_file_read, row);
			for (int j = 0; j < InputSize + 1; j++) {
				if (j == InputSize)
					outfile << trainInput[j];
				else
					outfile << trainInput[j] << ",";
			}
			if (i != DataCount - 1)
				outfile << "\n";
		}
		outfile.close();
	}
// Sisteme De�erleri ��retim Ad�mlar�
	void Model::Training() {
		//std::cout << W_Mtrx[0][784] << " - " << trainMtrx[0][785] << "\n";
		vector_A = new double[width]; // BIAS de�eri = width + 1 = width yap�ld�.
		vector_O = new double[height];
		vector_R = new double[width];
		vector_S = new double[height];
		for (int i = 0; i < TrainCount; i++) {
			int y = 1;
			vector_C = new double[height];
			for (int n = 0; n < height; n++) {
				vector_C[n] = 0.0;
			}
			vector_C[int(input_G[i][0])] = 1.0;
		backpropagation:
			double L1 = LAMDA1, L2 = LAMDA2;
			if (y < 100) { L1 *= 10; L2 *= 2; }
			else if (y < 1000) { L1 *= 1; L2 *= 1; }
			else { L1 *= 0.1; L2 *= 0.5; }/**/
		// Step a.
			double total = 0.0;
			for (int k = 0; k < width; k++) {
				for (int l = 0; l < InputSize; l++) {
					total = total + (weight_W[k][l] * input_G[i][l + 1]);
				}
				total += weight_W[k][InputSize] * BIAS; // BIAS'lar �arp�l�p toplama eklendi.
				vector_A[k] = total;
				total = 0.0;
			}
		// Step b.
			relu(vector_A, width); //RELU Normalizasyon
		// Step c.
			for (int k = 0; k < height; k++) {
				for (int l = 0; l < width; l++) {
					total += (weight_Y[k][l] * vector_R[l]);
				}
				total += weight_Y[k][width] * BIAS; // BIAS'lar �arp�l�p toplama eklendi.
				vector_O[k] = total;
				total = 0.0;
			}
		// Step d.
			double max = softmax(vector_O, height); //Softmax Normalizasyon
		// Hata De�eri(ErrVal) Hesapla
			double ErrVal = 0.0;
			for (int n = 0; n < height; n++) {
				ErrVal += pow(vector_S[n] - vector_C[n], 2);
			}
			ErrVal /= height; 
			//std::cout << "vector_S[" <<y<< "]" << vector_S[0] << "\n";
			/*for (int u = 0; u < height; u++) {
				
			}*/
			
		// ��renme Durumu
			if (ErrVal <= 0.00001) {
				for (int k = 0; k < height; k++) {
					if (vector_S[k] == max) {
						std::cout << i << ". Train Value   =>  " << input_G[i][0] << "\n";
						std::cout << "Result            => " << "[" << k << "]\n";
						std::cout << "Probability       =>  " << vector_S[k] << "\n";
						std::cout << "Error Value       =>  " << ErrVal << "\n";
					}
				}
				RED; std::cout << "BACK PROPAGATION  =>  " << y << "\n";
				GREEN; std::cout << "***** SUCCESS TRAIN *****" << "\n";
				WHITE;
			}
			else {
			// BackPropagation Step For Second Layer
				double pro = 0.0;
				for (int m = 0; m < height; m++) {
					for (int n = 0; n < width; n++) {
						pro = ( vector_R[n] * softmaxDerivative(vector_O, height, m) * L2 * (vector_S[m] - vector_C[m]) );
						weight_Y[m][n] -= pro;
						if (n == width - 1) {
							pro = (1 * softmaxDerivative(vector_O, height, m) * L2 * (vector_S[m] - vector_C[m]));
							weight_Y[m][n+1] -= pro;
						}
					}
				}
			// BackPropagation Step For First Layer
				double dRelu, subRelu, subY = 0.0;
				for (int m = 0; m < width; m++) {
					if (vector_A[m] < 0) 
						dRelu = 0.0;
					else {
						dRelu = 1.0;
						subY = 0.0;
						for (int p = 0; p < height; p++) {
							subY += (weight_Y[p][m] * softmaxDerivative(vector_O, height, p) * L1 * (vector_S[p] - vector_C[p]));
						}
						for (int n = 0; n < InputSize; n++) {
							weight_W[m][n] = ( weight_W[m][n] - (input_G[i][n + 1] * subY) );
						}
					}
				}
				y++;
				goto backpropagation;
			}
			std::cout << "\n";
		} //TrainCount Finished
		for (int i = 0; i < TrainCount; i++)
			delete[i] input_G[i];
		delete[] input_G;
		delete[] vector_A;
		delete[] vector_R;
		delete[] vector_O;
		delete[] vector_S;
		/**/
	}
// Sistemde De�erleri Test Etme Ad�mlar�
	void Model::Testing() {
		int a = 0;
		vector_A = new double[width]; // BIAS de�eri = width + 1 = width yap�ld�.
		vector_O = new double[height];
		vector_C = new double[height];
		vector_R = new double[width];
		vector_S = new double[height];
		for (int n = 0; n < height; n++) vector_C[n] = 0.0;
		std::cout << "   Requested   :   Guess   :    Result\n";
		for (int i = 0; i < TestCount; i++) {
			vector_C[int(test_G[i][0])] = 1.0;
			// Step a.
				double total = 0.0;
				for (int k = 0; k < width; k++) {
					for (int l = 0; l < InputSize; l++) {
						total = total + (weight_W[k][l] * test_G[i][l + 1]);
					}
					total += weight_W[k][InputSize] * BIAS; // BIAS'lar �arp�l�p toplama eklendi.
					vector_A[k] = total;
					total = 0.0;
				}
			// Step b.
				relu(vector_A, width); //RELU Normalizasyon
			// Step c.
				for (int k = 0; k < height; k++) {
					for (int l = 0; l < width; l++) {
						total += (weight_Y[k][l] * vector_R[l]);
					}
					total += weight_Y[k][width] * BIAS; // BIAS'lar �arp�l�p toplama eklendi.
					vector_O[k] = total;
					total = 0.0;
				}
			// Step d.
				double max = softmax(vector_O, height); //Softmax Normalizasyon
			// Test Durumu
				int maxim = 0;
				for (int k = 0; k < height; k++) {
					if (vector_S[k] == max) {
						maxim = k;
					}
				}
				if (test_G[i][0] == maxim) {
					std::cout	<< std::setw(8) << test_G[i][0] 
								<< std::setw(14) << maxim 
								<< std::setw(16);
					GREEN;
						std::cout << "TRUE\n";
					WHITE;
					a++;
				}
				else {
					std::cout	<< std::setw(8) << test_G[i][0] 
								<< std::setw(14) << maxim 
								<< std::setw(16);
					RED;
						std::cout << "FALSE\n";
					WHITE;
				}
				//std::cout << "";	
		}
		std::cout << "TRAINING PERCENT  => " << 100*a/TestCount <<"%\n";
		for (int i = 0; i < TestCount; i++)
			delete[i] test_G[i];
		delete[] test_G;
		for (int i = 0; i < width; i++)
			delete[i] weight_W[i];
		delete[] weight_W;
		for (int i = 0; i < height; i++)
			delete[i] weight_Y[i];
		delete[] weight_Y;
		delete[] vector_A;
		delete[] vector_R;
		delete[] vector_O;
		delete[] vector_S;
		delete[] vector_C;
	}
// relu() Function
	void Model::relu(double r[], int row) {
		//vector_R = new double [row];
		for (int m = 0; m < row; m++) {
			if (r[m] <= 0.0)
				vector_R[m] = 0.0;
			else
				vector_R[m] = r[m];
		}
	}
	// softmax() Function
	double Model::softmax(double o[], int row) {
		//vector_S = new double[row];
		double expSub = 0.0;
		for (int k = 0; k < row; k++) {
			expSub += std::exp(o[k]);
		}
		//if (expSub == 0.0) //expSub = 1;
		for (int k = 0; k < row; k++) {
			vector_S[k] = std::exp(o[k]) / expSub;
		}
		double max = vector_S[0];
		for (int k = 0; k < row; k++) {
			if (vector_S[k] > max) {
				max = vector_S[k];
			}
		}
		return max;
	}
// softmax() Function
	double Model::softmaxDerivative(double o[], int row, int h) {
		double expSub = 0.0, interSub = 0.0, derivate;
		for (int k = 0; k < row; k++) {
			expSub += std::exp(o[k]);
			if (k != h)
				interSub += std::exp(o[k]);
		}
		//if (expSub == 0.0) expSub = 1;
		derivate = (std::exp(o[h]) * interSub) / pow(expSub,2);
		return derivate;
	}
// Destructor
	Model::~Model() {}


	//std::cout << " vector_R[" << m << "] = " << r[m] << "\n";
	//std::cout << " vector_R[" << m << "] = " << vector_R[m] << "\n";

