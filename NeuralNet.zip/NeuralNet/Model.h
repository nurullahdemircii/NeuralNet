#pragma once
#define WHITE SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
#define RED SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED);
#define GREEN SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_GREEN);
#define BLUE SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_BLUE);
#define ORANGE SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_RED| FOREGROUND_GREEN);
#define TestCount 25
#include <windows.h>
class Model {
private:
	/* *** Add By Team ThreaData *** */
	int trainValue;			// It Will Learn of Value
	int width = 0;	// I/O Weight Matrix Width
	int height = 0;	// O/O Weight Matrix Height 
	double* trainInput;		// Train Array Values ( Gi[0,1,2,...,785] )
	int* subRowSize;	// One Row Size On Train File ( subRowSize[0,1,2,...,59999] )
	double** input_G;
	double** test_G;
	double** weight_W;		// Input Maatrix ( W[0,1,2,...,127][0,1,2,...,784] ) 
	double** weight_Y;		// Output Matrix ( Y[0,1,2,...,9][0,1,2,...,128] )
	double* vector_A;		// Interlayer For Training ( A[0,1,2,...,128] )
	double* vector_R;
	double* vector_O;		// Output Layer For Training ( O[0,1,2,...,9] )
	double* vector_S;
	double* vector_C;		// We want this Values ( C[0,1,2,...,9] )
	/* *** The Finished of Add By Team ThreaData *** */

public:
	/* *** Add By Team ThreaData *** */
	void LearnRowSize(std::string img_file_path, std::string TrainOrTest, int DataCount);
	void ReadTrainDatas(std::string img_file_path, int row);
	void CreatTrainMtrx(std::string img_file_path);
	void CreatTestMtrx(std::string img_file_path);
	void CreateWeightMtrx(std::string img_file_path, std::string name);
	void CreateTestFile(std::string img_file_read, std::string img_file_write, int DataCount);
	void Training();
	void Testing();
	void relu(double r[], int row);
	double softmax(double o[], int row);
	double softmaxDerivative(double o[], int row, int h);
	double softmaxDerivative2(double o);
	~Model();
	/* *** The Finished of Add By Team ThreaData *** */
};