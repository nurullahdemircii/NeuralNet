// main.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#define HAVE_STRUCT_TIMESPEC
#include <pthread.h>
#include "pch.h"
#include <iostream>
#include <string>
#include <ctime>
#include "Model.h"

//using namespace std;

int main() {

	//Test ve e�itim dosyalar�n� y�kle
	std::string weight1 = "..//NeuralNet_784_128_10//FCN0.txt";
	std::string weight2 = "..//NeuralNet_784_128_10//FCN1.txt";
	std::string train = "..//Train/mnist_train.csv";
	//std::string test = "..//Test/mnist_test.csv";
	std::string testMy = "..//Train/newTrain.csv";

	Model m;
	double clock1, clock2, clock3, clock4, clock5;

	// A��rl�k de�erlerini oku ve Neural Network� olu�tur
		clock_t start1 = clock(), finish1;
		m.CreateWeightMtrx(weight1, "W"); // Creating Input Martix = W
		m.CreateWeightMtrx(weight2, "Y"); // Creating Output Matrix = Y
		finish1 = clock();
		clock1 = (float)(finish1 - start1) / CLOCKS_PER_SEC;
		ORANGE;
			std::cout	<< "~~~ Create Weight Matrix Excute Time: " << clock1 << " ~~~\n\n";
		WHITE;

	//Giris Degerleri Ve �grenilecek deger dosyadan okundu.
		clock_t start2 = clock(), finish2;
		m.CreatTrainMtrx(train);
		finish2 = clock();
		clock2 = (float)(finish2 - start2) / CLOCKS_PER_SEC;
		ORANGE; 
			std::cout << "~~~ Create Train Matrix Excute Time: " << clock2 << " ~~~\n\n";
		WHITE;
	// Training.
		clock_t start3 = clock(), finish3;
		m.Training();
		finish3 = clock();
		clock3 = (float)(finish3 - start3) / CLOCKS_PER_SEC;
		ORANGE; 
			std::cout << "~~~ Create Weight Matrix Excute Time: " << clock1 << " ~~~\n";
			std::cout << "~~~ Create Train Matrix Excute Time: " << clock2 << " ~~~\n";
			std::cout << "~~~ Training Excute Time: " << clock3 << " ~~~\n\n";
		WHITE;
	// Yeni Test Dosyas� Olustur.
		m.CreateTestFile(train, testMy, TestCount);
	//Test Degerleri dosyadan okundu.
		clock_t start4 = clock(), finish4;
		m.CreatTestMtrx(testMy);
		finish4 = clock();
		clock4 = (float)(finish4 - start4) / CLOCKS_PER_SEC;
		ORANGE; 
			std::cout << "~~~ Create Test Matrix Excute Time: " << clock4 << " ~~~\n\n";
		WHITE;

	// Testng.
		clock_t start5 = clock(), finish5;
		m.Testing();
		finish5 = clock();
		clock5 = (float)(finish5 - start5) / CLOCKS_PER_SEC;
		ORANGE;
			std::cout << "~~~ Testing Excute Time: " << clock5 << " ~~~\n\n";
		WHITE
}
